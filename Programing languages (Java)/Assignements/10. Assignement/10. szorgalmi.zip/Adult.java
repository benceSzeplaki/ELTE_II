public class Adult extends Guest
{
    public Adult(String innit_name, int innit_age)
    {
        super(innit_name, innit_age);
    }
}