public class Minor extends Guest
{
    public Minor(String innit_name, int innit_age)
    {
        super(innit_name, innit_age);
    }
}